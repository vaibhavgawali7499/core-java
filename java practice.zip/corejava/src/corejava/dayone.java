package corejava;

public class dayone {
public static void main(String[]args) {
	System.out.println("Hello Students!!");
	dayone d=new dayone();
	d.main();
}
void main()
{
	System.out.println("This is my own main function");
}

}


